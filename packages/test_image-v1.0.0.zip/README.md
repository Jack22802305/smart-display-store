# Test Image Display

A simple test mode for verifying the app store system works correctly.

## What it does

Displays a static test image on your ESP32 display.

## Features

- Static image display
- Lightweight (< 1 MB)
- Perfect for testing

## Installation

Install from the App Store with one click!

## Usage

1. Activate the mode from the Modes tab
2. Image will display on your screen

## Version History

- **1.0.0** - Initial release

